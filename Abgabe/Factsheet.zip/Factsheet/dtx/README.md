The fhnwfactsheet LaTeX Class
=============================

Run twice to get all references correct:
```
make
make
```

References
==========

The multi-lingual mechanism for the documentation is courtesy of Martin Scharrer
from this answer:
https://tex.stackexchange.com/a/28646/131649
