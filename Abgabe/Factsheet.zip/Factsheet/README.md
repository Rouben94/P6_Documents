FHNW Fact Sheet LaTeX Class
===========================

A LaTeX Class for creating project fact sheets.
